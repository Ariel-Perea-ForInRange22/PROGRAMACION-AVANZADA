package Parte2;

import Parte2.controladores.ControladorInsumos;
import Parte2vista.VistaInsumos;

import java.awt.BorderLayout;
import javax.swing.*;

public class Practica03_a extends JFrame {
    private ListaInsumos listaInsumos;
    private ListaCategorias listaCategorias;
    private ControladorInsumos controladorInsumos;
    private VistaInsumos vistaInsumos;
    private JComboBox comboCategoria;
    private JTextField tId, tInsumo;
    private JButton bAgregar, bEliminar, bSalir;
    private JPanel panelFormulario;

    public Practica03_a() {
        super("Administración de Productos");
        this.listaCategorias = new ListaCategorias();
        this.listaInsumos = new ListaInsumos();
        this.vistaInsumos = new VistaInsumos();
        this.controladorInsumos = new ControladorInsumos(listaInsumos, vistaInsumos);

        inicializarCategorias();
        configurarInterfaz();
    }

    private void inicializarCategorias() {
        Categoria nodo1 = new Categoria("01", "Materiales");
        Categoria nodo2 = new Categoria("02", "Mano de Obra");
        Categoria nodo3 = new Categoria("03", "Maquinaria y Equipo");
        Categoria nodo4 = new Categoria("04", "Servicios");
        listaCategorias.agregarCategoria(nodo1);
        listaCategorias.agregarCategoria(nodo2);
        listaCategorias.agregarCategoria(nodo3);
        listaCategorias.agregarCategoria(nodo4);
    }

    private void configurarInterfaz() {
        setBounds(0, 0, 390, 370);
        panelFormulario = new JPanel();
        panelFormulario.setLayout(null);
        getContentPane().add(panelFormulario, BorderLayout.CENTER);

        JLabel labelCategoria = new JLabel("Categoría:");
        labelCategoria.setBounds(10, 66, 71, 20);
        panelFormulario.add(labelCategoria);
        comboCategoria = new JComboBox(listaCategorias.CategoriasArreglo());
        comboCategoria.setEditable(false);
        comboCategoria.setBounds(91, 66, 160, 20);
        comboCategoria.addActionListener(e -> {});
        panelFormulario.add(comboCategoria);

        JLabel labelId = new JLabel("ID:");
        labelId.setBounds(10, 9, 71, 20);
        tId = new JTextField(10);
        tId.setEditable(true);
        tId.setBounds(91, 9, 147, 20);
        panelFormulario.add(labelId);
        panelFormulario.add(tId);

        JLabel labelInsumo = new JLabel("Insumo:");
        labelInsumo.setBounds(10, 34, 71, 20);
        tInsumo = new JTextField(20);
        tInsumo.setEditable(true);
        tInsumo.setBounds(91, 35, 147, 20);
        panelFormulario.add(labelInsumo);
        panelFormulario.add(tInsumo);

        bAgregar = new JButton("Agregar");
        bAgregar.setBounds(20, 104, 111, 20);
        bAgregar.addActionListener(e -> Altas());
        panelFormulario.add(bAgregar);

        bEliminar = new JButton("Eliminar");
        bEliminar.setBounds(153, 104, 111, 20);
        bEliminar.addActionListener(e -> Eliminar());
        panelFormulario.add(bEliminar);

        bSalir = new JButton("Salir");
        bSalir.setBounds(274, 104, 79, 20);
        bSalir.addActionListener(e -> {
            if (bSalir.getText().compareTo("Cancelar") == 0) {
                Volveralinicio();
            } else {
                dispose();
            }
        });
        panelFormulario.add(bSalir);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 132, 357, 179);
        panelFormulario.add(scrollPane);
        JTextArea areaProductos = new JTextArea(10, 40);
        scrollPane.setViewportView(areaProductos);
        areaProductos.setEditable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void Volveralinicio() {
        bAgregar.setText("Agregar");
        bSalir.setText("Salir");
        bEliminar.setEnabled(true);
        tId.setEditable(false);
        tInsumo.setEditable(false);
        comboCategoria.setEditable(false);
        tId.setText("");
        tInsumo.setText("");
        comboCategoria.setSelectedIndex(0);
    }

    public void Altas() {
        if (bAgregar.getText().compareTo("Agregar") == 0) {
            bAgregar.setText("Salvar");
            bSalir.setText("Cancelar");
            bEliminar.setEnabled(false);
            tId.setEditable(true);
            tInsumo.setEditable(true);
            comboCategoria.setEditable(true);
            comboCategoria.setFocusable(true);
        } else {
            if (esdatoscompletos()) {
                String id = tId.getText().trim();
                String insumo = tInsumo.getText().trim();
                String idcategoria = ((Categoria) comboCategoria.getSelectedItem()).getIdcategoria().trim();
                Insumo nodo = new Insumo(id, insumo, idcategoria);
                controladorInsumos.agregarInsumo(nodo);
            }
            Volveralinicio();
        }
    }

    private boolean esdatoscompletos() {
        boolean completos = true;
        if (tId.getText().trim().isEmpty() || tInsumo.getText().trim().isEmpty()) {
            completos = false;
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
        }
        return completos;
    }

    public void Eliminar() {
        Object[] opciones = listaInsumos.idinsumos();
        String id = (String) JOptionPane.showInputDialog(null, "Seleccione una opción:", "Eliminación de Insumos", JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
        if ((id != null) && (!id.isEmpty())) {
            controladorInsumos.eliminarInsumo(id);
        }
    }

    public static void main(String[] args) {
        new Practica03_a();
    }
}
		