package Parte2.controladores;

import Parte2.ListaInsumos;
import Parte2.Insumo;
import Parte2vista.VistaInsumos;

public class ControladorInsumos {
    private ListaInsumos listaInsumos;
    private VistaInsumos vistaInsumos;

    public ControladorInsumos(ListaInsumos listaInsumos, VistaInsumos vistaInsumos) {
        this.listaInsumos = listaInsumos;
        this.vistaInsumos = vistaInsumos;
    }

    public void agregarInsumo(Insumo insumo) {
        if (listaInsumos.agregarInsumo(insumo)) {
            vistaInsumos.actualizarVista(listaInsumos.toString());
        } else {
            vistaInsumos.mostrarError("El ID " + insumo.getIdProducto() + " ya existe.");
        }
    }

    public void eliminarInsumo(String id) {
        Insumo insumo = new Insumo(id, "", "");
        if (listaInsumos.eliminarInsumo(insumo)) {
            vistaInsumos.actualizarVista(listaInsumos.toString());
        } else {
            vistaInsumos.mostrarError("No existe un insumo con el ID " + id);
        }
    }
}

