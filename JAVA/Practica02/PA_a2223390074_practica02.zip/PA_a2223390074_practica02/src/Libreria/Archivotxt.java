package Libreria;

import java.util.ArrayList;

public class Archivotxt {
    // Implementación de métodos necesarios
    public boolean existe() {
        // Lógica para verificar si el archivo existe
        return true;
    }

    public ArrayList<String[]> cargar() {
        // Lógica para cargar datos desde el archivo
        return new ArrayList<>();
    }
}