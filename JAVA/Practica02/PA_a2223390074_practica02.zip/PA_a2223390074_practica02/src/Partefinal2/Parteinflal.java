package Partefinal2;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class Parteinflal extends JFrame implements ActionListener {

    private JDesktopPane desktopPane;
    private JMenuBar menuBar;
    private JMenu menu, menuConfiguracion;
    private JMenuItem menuItemCategorias, menuItemObras, menuItemConfigurar;

    public Parteinflal() {
        setTitle("Parteinflal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new CardLayout());

        desktopPane = new JDesktopPane();
        add(desktopPane);

        menuBar = new JMenuBar();
        menu = new JMenu("Opciones");
        menuBar.add(menu);

        menuItemCategorias = new JMenuItem("Categorías");
        menuItemCategorias.addActionListener(this);
        menu.add(menuItemCategorias);

        menuItemObras = new JMenuItem("Obras");
        menuItemObras.addActionListener(this);
        menu.add(menuItemObras);

        menuConfiguracion = new JMenu("Configuración");
        menuBar.add(menuConfiguracion);

        menuItemConfigurar = new JMenuItem("Configurar Base de Datos");
        menuItemConfigurar.addActionListener(this);
        menuConfiguracion.add(menuItemConfigurar);

        setJMenuBar(menuBar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menuItemCategorias) {
            CategoriasFrame categoriasFrame = new CategoriasFrame();
            desktopPane.add(categoriasFrame);
            categoriasFrame.setVisible(true);
            menuItemCategorias.setEnabled(false);

            categoriasFrame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
                public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
                    menuItemCategorias.setEnabled(true);
                }
            });
        } else if (e.getSource() == menuItemObras) {
            ObrasFrame obrasFrame = new ObrasFrame();
            desktopPane.add(obrasFrame);
            obrasFrame.setVisible(true);
            menuItemObras.setEnabled(false);

            obrasFrame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
                public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
                    menuItemObras.setEnabled(true);
                }
            });
        } else if (e.getSource() == menuItemConfigurar) {
            String[] opciones = {"txt", "xml"};
            String seleccion = (String) JOptionPane.showInputDialog(this, "Seleccione el tipo de base de datos:", "Configuración", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            if (seleccion != null) {
                Configuracion.setTipoBaseDatos(seleccion);
            }
        }
    }

    public static void main(String[] args) {
        Parteinflal frame = new Parteinflal();
        frame.setVisible(true);
    }
}