package Parte2vista;

import javax.swing.*;

public class VistaInsumos extends JFrame {
    private JTextArea areaVista;

    public VistaInsumos() {
        super("Vista de Insumos");
        setBounds(400, 0, 390, 370);
        areaVista = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(areaVista);
        getContentPane().add(scrollPane);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actualizarVista(String texto) {
        areaVista.setText(texto);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
