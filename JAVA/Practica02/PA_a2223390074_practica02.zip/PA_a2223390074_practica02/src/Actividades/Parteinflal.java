package Actividades;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Parteinflal extends JFrame implements ActionListener {

    private JDesktopPane desktopPane;
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem menuItemCategorias, menuItemObras;

    public Parteinflal() {
        setTitle("Parteinflal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new CardLayout());

        desktopPane = new JDesktopPane();
        add(desktopPane);

        menuBar = new JMenuBar();
        menu = new JMenu("Opciones");
        menuBar.add(menu);

        menuItemCategorias = new JMenuItem("Categorías");
        menuItemCategorias.addActionListener(this);
        menu.add(menuItemCategorias);

        menuItemObras = new JMenuItem("Obras");
        menuItemObras.addActionListener(this);
        menu.add(menuItemObras);

        setJMenuBar(menuBar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menuItemCategorias) {
            CategoriasFrame categoriasFrame = new CategoriasFrame();
            desktopPane.add(categoriasFrame);
            categoriasFrame.setVisible(true);
            menuItemCategorias.setEnabled(false);

            categoriasFrame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
                public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
                    menuItemCategorias.setEnabled(true);
                }
            });
        } else if (e.getSource() == menuItemObras) {
            ObrasFrame obrasFrame = new ObrasFrame();
            desktopPane.add(obrasFrame);
            obrasFrame.setVisible(true);
            menuItemObras.setEnabled(false);

            obrasFrame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
                public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
                    menuItemObras.setEnabled(true);
                }
            });
        }
    }

    public static void main(String[] args) {
        Parteinflal frame = new Parteinflal();
        frame.setVisible(true);
    }
}