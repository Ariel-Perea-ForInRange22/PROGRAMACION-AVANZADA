package Parte2;

import Parte2.*;
import Parte2.librería.Archivotxt;
import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.*;

public class Practica03_c extends JFrame {
    private ListaCategorias listaCategorias;
    private JTextField tId, tCategoria;
    private JTextArea tAreaCategoria;
    private JButton bAgregar, bEliminar, bGuardar, bCargar, bSalir;
    private JPanel panelFormulario;
    private Archivotxt archivoTxt;

    public Practica03_c() {
        super("Administración de Categorias");
        this.listaCategorias = new ListaCategorias();
        this.archivoTxt = new Archivotxt("categorias.txt");

        inicializarCategorias();
        configurarInterfaz();
    }

    private void inicializarCategorias() {
        Categoria nodo1 = new Categoria("01", "Materiales");
        Categoria nodo2 = new Categoria("02", "Mano de Obra");
        Categoria nodo3 = new Categoria("03", "Maquinaria y Equipo");
        Categoria nodo4 = new Categoria("04", "Servicios");
        listaCategorias.agregarCategoria(nodo1);
        listaCategorias.agregarCategoria(nodo2);
        listaCategorias.agregarCategoria(nodo3);
        listaCategorias.agregarCategoria(nodo4);
    }

    private void configurarInterfaz() {
        setBounds(0, 0, 390, 370);
        panelFormulario = new JPanel();
        panelFormulario.setLayout(null);
        getContentPane().add(panelFormulario, BorderLayout.CENTER);

        JLabel labelId = new JLabel("ID:");
        labelId.setBounds(10, 9, 71, 20);
        tId = new JTextField(10);
        tId.setEditable(false);
        tId.setBounds(91, 9, 147, 20);
        panelFormulario.add(labelId);
        panelFormulario.add(tId);

        JLabel labelCategoria = new JLabel("Categoría:");
        labelCategoria.setBounds(10, 34, 71, 20);
        tCategoria = new JTextField(20);
        tCategoria.setEditable(false);
        tCategoria.setBounds(91, 35, 147, 20);
        panelFormulario.add(labelCategoria);
        panelFormulario.add(tCategoria);

        bAgregar = new JButton("Agregar");
        bAgregar.setBounds(20, 104, 111, 20);
        bAgregar.addActionListener(e -> agregarCategoria());
        panelFormulario.add(bAgregar);

        bEliminar = new JButton("Eliminar");
        bEliminar.setBounds(153, 104, 111, 20);
        bEliminar.addActionListener(e -> eliminarCategoria());
        panelFormulario.add(bEliminar);

        bGuardar = new JButton("Guardar");
        bGuardar.setBounds(20, 140, 111, 20);
        bGuardar.addActionListener(e -> guardarCategorias());
        panelFormulario.add(bGuardar);

        bCargar = new JButton("Cargar");
        bCargar.setBounds(153, 140, 111, 20);
        bCargar.addActionListener(e -> cargarCategorias());
        panelFormulario.add(bCargar);

        bSalir = new JButton("Salir");
        bSalir.setBounds(274, 104, 79, 20);
        bSalir.addActionListener(e -> dispose());
        panelFormulario.add(bSalir);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 170, 357, 141);
        panelFormulario.add(scrollPane);
        tAreaCategoria = new JTextArea(10, 40);
        tAreaCategoria.setEditable(false);
        scrollPane.setViewportView(tAreaCategoria);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void agregarCategoria() {
        tId.setEditable(true);
        tCategoria.setEditable(true);
        String id = tId.getText().trim();
        String categoria = tCategoria.getText().trim();
        Categoria nodo = new Categoria(id, categoria);
        listaCategorias.agregarCategoria(nodo);
        tAreaCategoria.setText(listaCategorias.toLinea());
        Volveralinicio();
    }

    private void eliminarCategoria() {
        String id = JOptionPane.showInputDialog("Ingrese el ID de la categoría a eliminar:");
        Categoria nodo = new Categoria(id, "");
        listaCategorias.eliminarCategoria(nodo);
        tAreaCategoria.setText(listaCategorias.toLinea());
    }

    private void guardarCategorias() {
        StringBuilder datos = new StringBuilder();
        for (Categoria categoria : listaCategorias.obtenerLista()) {
            datos.append(categoria.getIdcategoria()).append(",").append(categoria.getCategoria()).append("\n");
        }
        archivoTxt.guardar(datos.toString());
        JOptionPane.showMessageDialog(this, "Categorías guardadas en el archivo.");
    }

    private void cargarCategorias() {
        ArrayList<String[]> lineas = archivoTxt.cargar();
        listaCategorias = new ListaCategorias();
        cargarCategorias(lineas);
        tAreaCategoria.setText(listaCategorias.toLinea());
    }

    public void cargarCategorias(ArrayList<String[]> categoriasString) {
        for (String[] categoriaString : categoriasString) {
            String idCategoria = categoriaString[0];
            String nombreCategoria = categoriaString[1];
            Categoria categoria = new Categoria(idCategoria, nombreCategoria);
            listaCategorias.agregarCategoria(categoria);
        }
    }

    public void Volveralinicio() {
        tId.setEditable(false);
        tCategoria.setEditable(false);
        tId.setText("");
        tCategoria.setText("");
    }

    public static void main(String[] args) {
        new Practica03_c();
    }
}
