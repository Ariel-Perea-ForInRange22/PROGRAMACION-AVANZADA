package Parte2;

import java.util.List;
import java.util.Optional;

public class ListaInsumos {
    private Lista<Insumo> insumos;

    public ListaInsumos() {
        this.insumos = new Lista<>();
    }

    public boolean agregarInsumo(Insumo insumo) {
        return insumos.insertar(insumo);
    }

    public boolean eliminarInsumo(Insumo insumo) {
        return insumos.eliminar(insumo);
    }

    public String toString() {
        String resultado = "";
        for (Insumo insumo : insumos.obtenerLista()) {
            resultado += insumo.toString() + "\n";
        }
        return resultado;
    }

    public Insumo buscarInsumo(Insumo insumo) {
        Optional<Insumo> resultado = insumos.buscar(insumo);
        return resultado.orElse(null);
    }

    public String[] idinsumos() {
        return insumos.toStringArreglo("idProducto");
    }

    public List<Insumo> obtenerLista() {
        return insumos.obtenerLista();
    }
}

