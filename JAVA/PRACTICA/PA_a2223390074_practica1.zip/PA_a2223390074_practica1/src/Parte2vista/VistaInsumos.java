package Parte2vista;

import javax.swing.*;

public class VistaInsumos extends JFrame {
    private JTextArea areaProductos;

    public VistaInsumos() {
        super("Vista de Insumos");
        setBounds(0, 0, 390, 370);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 132, 357, 179);
        add(scrollPane);

        areaProductos = new JTextArea(10, 40);
        scrollPane.setViewportView(areaProductos);
        areaProductos.setEditable(false);
    }

    public void actualizarVista(String texto) {
        areaProductos.setText(texto);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
}

