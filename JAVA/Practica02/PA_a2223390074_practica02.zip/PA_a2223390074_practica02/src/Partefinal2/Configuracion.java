package Partefinal2;

public class Configuracion {
    private static String tipoBaseDatos = "txt"; // Valor por defecto

    public static String getTipoBaseDatos() {
        return tipoBaseDatos;
    }

    public static void setTipoBaseDatos(String tipo) {
        tipoBaseDatos = tipo;
    }
}