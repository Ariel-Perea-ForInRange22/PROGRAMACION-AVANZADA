
package Vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JList;
import javax.swing.JTextField;

public class Practica03_b extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // Variables globales
    private JFrame padre;
    private JMenuBar barra;
    private JList<String> ListaCategorias;
    private JTextField txtNombreCategoria;
    private JButton btnAgregarCategoria;
    private JMenu mnuArchivo;
    private JMenuItem mnuSalir;

    public Practica03_b(JFrame Padre) {
        this.padre = Padre;
        this.barra = this.padre.getJMenuBar();
        // Assuming libreria is a static method or class, otherwise define it
        // this.barra = this.libreria.menubar(this.barra);

        setTitle("Administración de Productos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        // Inicializar componentes del menú
        mnuArchivo = new JMenu("Archivo");
        mnuSalir = new JMenuItem("Salir");
        mnuArchivo.add(mnuSalir);
        barra.add(mnuArchivo);

        // Inicializar otros componentes
        ListaCategorias = new JList<>();
        txtNombreCategoria = new JTextField();
        btnAgregarCategoria = new JButton("Agregar Categoría");

        // Agregar ActionListener
        btnAgregarCategoria.addActionListener(this);
        mnuSalir.addActionListener(this);
    }

    public void inicializarcategorias() {
        // Implementación del método para inicializar categorías
    }

    public void habilitarmenu(JMenuBar barramenu, boolean estado) {
        for (int i = 0; i < barramenu.getMenuCount(); i++) {
            barramenu.getMenu(i).setEnabled(estado);
        }
        // Assuming libreria is a static method or class, otherwise define it
        // this.libreria.habilitarmenus(barramenu, estado);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAgregarCategoria) {
            // Implementar la lógica para agregar categoría
        } else if (e.getSource() == mnuSalir) {
            // Implementar la lógica para salir
        }
    }

    // Define or remove these methods if not needed
    // public void Altas() {}
    // public void Eliminar() {}
    // public void Volveralinicio() {}
}
