
package Actividades;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Practica05 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private JDesktopPane desktopPane;
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem menuItemPractica03;

	public Practica05() {
		setTitle("Aplicación Principal");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		desktopPane = new JDesktopPane();
		add(desktopPane, BorderLayout.CENTER);

		menuBar = new JMenuBar();
		menu = new JMenu("Opciones");
		menuBar.add(menu);

		menuItemPractica03 = new JMenuItem("Abrir Practica03_c");
		menuItemPractica03.addActionListener(this);
		menu.add(menuItemPractica03);

		setJMenuBar(menuBar);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == menuItemPractica03) {
			Practica03_c practica03 = new Practica03_c();
			desktopPane.add(practica03);
			practica03.setVisible(true);
			menuItemPractica03.setEnabled(false);

			practica03.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
				public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
					menuItemPractica03.setEnabled(true);
				}
			});
		}
	}

	public static void main(String[] args) {
		Practica05 frame = new Practica05();
		frame.setVisible(true);
	}
}
