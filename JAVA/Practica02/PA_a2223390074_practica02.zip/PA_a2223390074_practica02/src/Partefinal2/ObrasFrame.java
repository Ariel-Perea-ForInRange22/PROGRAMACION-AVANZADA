package Partefinal2;

import java.awt.GridBagConstraints;

import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ObrasFrame extends JInternalFrame implements ActionListener {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton addButton;

    public ObrasFrame() {
        setTitle("Obras");
        setSize(600, 400);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        JPanel panel = new JPanel(new GridBagLayout());
        add(panel);

        tableModel = new DefaultTableModel(new Object[]{"Nombre", "Descripción", "Fecha de Creación"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panel.add(scrollPane, gbc);

        addButton = new JButton("Añadir Obra");
        addButton.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        panel.add(addButton, gbc);

        cargarDatos();
    }

    private void cargarDatos() {
        String tipoBaseDatos = Configuracion.getTipoBaseDatos();
        if (tipoBaseDatos.equals("txt")) {
            cargarDatosDesdeTXT();
        } else if (tipoBaseDatos.equals("xml")) {
            cargarDatosDesdeXML();
        }
    }

    private void cargarDatosDesdeTXT() {
        try (BufferedReader br = new BufferedReader(new FileReader("obras.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                tableModel.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarDatosDesdeXML() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse("obras.xml");
            NodeList nodeList = doc.getElementsByTagName("obra");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
                String nombre = element.getElementsByTagName("nombre").item(0).getTextContent();
                String descripcion = element.getElementsByTagName("descripcion").item(0).getTextContent();
                String fechaCreacion = element.getElementsByTagName("fechaCreacion").item(0).getTextContent();
                tableModel.addRow(new Object[]{nombre, descripcion, fechaCreacion});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void guardarDatos() {
        String tipoBaseDatos = Configuracion.getTipoBaseDatos();
        if (tipoBaseDatos.equals("txt")) {
            guardarDatosEnTXT();
        } else if (tipoBaseDatos.equals("xml")) {
            guardarDatosEnXML();
        }
    }

    private void guardarDatosEnTXT() {
        try (FileWriter fw = new FileWriter("obras.txt")) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                    fw.write(tableModel.getValueAt(i, j).toString());
                    if (j < tableModel.getColumnCount() - 1) {
                        fw.write(",");
                    }
                }
                fw.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarDatosEnXML() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();
            Element rootElement = doc.createElement("obras");
            doc.appendChild(rootElement);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                Element obraElement = doc.createElement("obra");
                rootElement.appendChild(obraElement);

                Element nombreElement = doc.createElement("nombre");
                nombreElement.appendChild(doc.createTextNode(tableModel.getValueAt(i, 0).toString()));
                obraElement.appendChild(nombreElement);

                Element descripcionElement = doc.createElement("descripcion");
                descripcionElement.appendChild(doc.createTextNode(tableModel.getValueAt(i, 1).toString()));
                obraElement.appendChild(descripcionElement);

                Element fechaCreacionElement = doc.createElement("fechaCreacion");
                fechaCreacionElement.appendChild(doc.createTextNode(tableModel.getValueAt(i, 2).toString()));
                obraElement.appendChild(fechaCreacionElement);
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult("obras.xml");
            transformer.transform(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            String nombre = JOptionPane.showInputDialog(this, "Nombre de la obra:");
            String descripcion = JOptionPane.showInputDialog(this, "Descripción de la obra:");
            String fechaCreacion = JOptionPane.showInputDialog(this, "Fecha de creación:");
            if (nombre != null && descripcion != null && fechaCreacion != null) {
                tableModel.addRow(new Object[]{nombre, descripcion, fechaCreacion});
                guardarDatos();
            }
        }
    }
}