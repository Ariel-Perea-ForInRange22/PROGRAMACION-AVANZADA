package Modelo;

import java.util.List;
import java.util.Optional;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;

public class ListaCategorias {
    private Lista<Categoria> categorias;

    public ListaCategorias() {
        this.categorias = new Lista<>();
    }

    public void agregarCategoria(Categoria categoria) {
        categorias.insertar(categoria);
    }

    public void eliminarCategoria(Categoria categoria) {
        categorias.eliminar(categoria);
    }

    public String toLinea() {
        String resultado = "";
        for (Categoria categoria : categorias.obtenerLista()) {
            resultado += categoria.toString() + "\n";
        }
        return resultado;
    }

    public Categoria buscarCategoria(Categoria categoria) {
        Optional<Categoria> resultado = categorias.buscar(categoria);
        return resultado.orElse(null);
    }

    public JComboBox agregarCategoriasAComboBox(JComboBox comboBox) {
        return categorias.agregarAComboBox(comboBox);
    }

    public Object[] CategoriasArreglo() {
        return categorias.obtenerLista().toArray();
    }

    public List<Categoria> obtenerLista() {
        return categorias.obtenerLista();
    }

    public DefaultListModel<Categoria> generarModeloCategorias() {
        DefaultListModel<Categoria> modelo = new DefaultListModel<>();
        for (Categoria categoria : categorias.obtenerLista()) {
            modelo.addElement(categoria);
        }
        return modelo;
    }
}
