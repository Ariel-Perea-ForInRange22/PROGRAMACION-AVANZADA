package Parte2.librería;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

public class ArchivoJson {
    private String nombreArchivo;

    public ArchivoJson(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public void guardar(String datos) {
        try (FileWriter file = new FileWriter(nombreArchivo)) {
            file.write(datos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String cargar() {
        StringBuilder datos = new StringBuilder();
        try (FileReader file = new FileReader(nombreArchivo)) {
            int i;
            while ((i = file.read()) != -1) {
                datos.append((char) i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return datos.toString();
    }
}