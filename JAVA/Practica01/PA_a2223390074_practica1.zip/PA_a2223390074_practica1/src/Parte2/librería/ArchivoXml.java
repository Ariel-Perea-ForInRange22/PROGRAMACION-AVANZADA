package Parte2.librería;

import java.io.*;
import com.thoughtworks.xstream.XStream;

import Parte2.Insumo;

import java.util.ArrayList;
import java.util.List;

public class ArchivoXml {
    private String archivoXml;

    public ArchivoXml(String archivoXml) {
        this.archivoXml = archivoXml;
    }

    // Guardar la lista de insumos en un archivo XML
    public void guardar(List<Insumo> insumos) {
        XStream xstream = new XStream();
        String xml = xstream.toXML(insumos);  // Convierte la lista de insumos a XML

        try (FileWriter writer = new FileWriter(archivoXml)) {
            writer.write(xml);  // Guarda el contenido XML en el archivo
            System.out.println("Datos guardados correctamente en: " + archivoXml);
        } catch (IOException e) {
            System.out.println("Error al guardar el archivo XML: " + e.getMessage());
        }
    }

    // Cargar los datos del archivo XML
    public List<Insumo> cargar() {
        XStream xstream = new XStream();
        List<Insumo> insumos = null;

        File file = new File(archivoXml);
        if (!file.exists()) {
            System.out.println("El archivo no existe, se creará uno nuevo.");
            return new ArrayList<>();  // Devuelve una lista vacía si el archivo no existe
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(archivoXml))) {
            StringBuilder xml = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                xml.append(line).append("\n");
            }

            // Deserializa el XML a una lista de insumos
            insumos = (List<Insumo>) xstream.fromXML(xml.toString());
        } catch (IOException e) {
            System.out.println("Error al cargar el archivo XML: " + e.getMessage());
        }

        return insumos;
    }
}
