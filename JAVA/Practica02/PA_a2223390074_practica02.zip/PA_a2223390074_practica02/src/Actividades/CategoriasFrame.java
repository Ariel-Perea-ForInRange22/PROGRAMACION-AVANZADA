package Actividades;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CategoriasFrame extends JInternalFrame implements ActionListener {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton addButton;

    public CategoriasFrame() {
        setTitle("Categorías");
        setSize(600, 400);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        JPanel panel = new JPanel(new FlowLayout());
        add(panel);

        tableModel = new DefaultTableModel(new Object[]{"Nombre", "Descripción"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);

        addButton = new JButton("Añadir Categoría");
        addButton.addActionListener(this);
        panel.add(addButton);

        cargarDatos();
    }

    private void cargarDatos() {
        try (BufferedReader br = new BufferedReader(new FileReader("categorias.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                tableModel.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarDatos() {
        try (FileWriter fw = new FileWriter("categorias.txt")) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                    fw.write(tableModel.getValueAt(i, j).toString());
                    if (j < tableModel.getColumnCount() - 1) {
                        fw.write(",");
                    }
                }
                fw.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            String nombre = JOptionPane.showInputDialog(this, "Nombre de la categoría:");
            String descripcion = JOptionPane.showInputDialog(this, "Descripción de la categoría:");
            if (nombre != null && descripcion != null) {
                tableModel.addRow(new Object[]{nombre, descripcion});
                guardarDatos();
            }
        }
    }
}