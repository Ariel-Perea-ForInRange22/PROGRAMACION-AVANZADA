package Actividades;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Practica03_c extends JInternalFrame implements ActionListener {

    private JTextField Tid, Tinsumo, Tcategoria;
    private JButton Bagregar, Beliminar, Bsalir;
    private JPanel panelFormulario;
    private JTable table;
    private DefaultTableModel tableModel;

    public Practica03_c() {
        setTitle("Administración de Productos");
        setSize(600, 400);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        panelFormulario = new JPanel();
        add(panelFormulario, BorderLayout.CENTER);
        panelFormulario.setLayout(null);

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(50, 20, 100, 20);
        panelFormulario.add(lblId);

        Tid = new JTextField();
        Tid.setBounds(150, 20, 200, 20);
        Tid.setEditable(false);
        panelFormulario.add(Tid);

        JLabel lblInsumo = new JLabel("Insumo:");
        lblInsumo.setBounds(50, 60, 100, 20);
        panelFormulario.add(lblInsumo);

        Tinsumo = new JTextField();
        Tinsumo.setBounds(150, 60, 200, 20);
        panelFormulario.add(Tinsumo);

        JLabel lblCategoria = new JLabel("Categoría:");
        lblCategoria.setBounds(50, 100, 100, 20);
        panelFormulario.add(lblCategoria);

        Tcategoria = new JTextField();
        Tcategoria.setBounds(150, 100, 200, 20);
        Tcategoria.setEditable(false);
        panelFormulario.add(Tcategoria);

        Bagregar = new JButton("Agregar");
        Bagregar.setBounds(50, 150, 100, 30);
        panelFormulario.add(Bagregar);
        Bagregar.addActionListener(this);

        Beliminar = new JButton("Eliminar");
        Beliminar.setBounds(160, 150, 100, 30);
        panelFormulario.add(Beliminar);
        Beliminar.addActionListener(this);

        Bsalir = new JButton("Salir");
        Bsalir.setBounds(270, 150, 100, 30);
        panelFormulario.add(Bsalir);
        Bsalir.addActionListener(this);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Insumo", "Categoría"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 200, 500, 150);
        panelFormulario.add(scrollPane);

        cargarDatos();
    }

    private void cargarDatos() {
        try (BufferedReader br = new BufferedReader(new FileReader("datos.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                tableModel.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarDatos() {
        try (FileWriter fw = new FileWriter("datos.txt")) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                for (int j = 0; j < tableModel.getColumnCount(); j++) {
                    fw.write(tableModel.getValueAt(i, j).toString());
                    if (j < tableModel.getColumnCount() - 1) {
                        fw.write(",");
                    }
                }
                fw.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Bagregar) {
            String id = Tid.getText().trim();
            String insumo = Tinsumo.getText().trim();
            String categoria = Tcategoria.getText().trim();

            if (!id.isEmpty() && !insumo.isEmpty() && !categoria.isEmpty()) {
                boolean existe = false;
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    if (tableModel.getValueAt(i, 0).equals(id)) {
                        existe = true;
                        break;
                    }
                }
                if (!existe) {
                    tableModel.addRow(new Object[]{id, insumo, categoria});
                    guardarDatos();
                } else {
                    System.out.println("El ID ya existe");
                }
            } else {
                System.out.println("Faltan datos");
            }
        } else if (e.getSource() == Beliminar) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
                guardarDatos();
            } else {
                System.out.println("Seleccione una fila para eliminar");
            }
        } else if (e.getSource() == Bsalir) {
            dispose();
        }
    }
}