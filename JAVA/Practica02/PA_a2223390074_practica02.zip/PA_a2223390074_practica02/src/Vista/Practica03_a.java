package Vista;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Libreria.Archivotxt;
import Modelo.Categoria;
import Modelo.ListaCategorias;
import Modelo.ListaInsumos;
import Modelo.Insumo;

import javax.swing.ScrollPaneConstants;

public class Practica03_a extends JFrame implements ActionListener {

    // declararemos los objetos para el manejo de categorias y productos y el archivo categoria
    ListaInsumos listaInsumos;
    ListaCategorias listaCategorias; 
    // declaracion de los objetos de los controles
    private JList<Categoria> ListaCategoria;
    private JTextField Tid, Tinsumo;
    private JButton Bagregar, Beliminar, Bsalir, Bguardar, Bcancelar;
    private JTextArea areaProductos;
    private DefaultListModel<Categoria> modeloCategoria;
    private JPanel panelFormulario;
    private Archivotxt archivo;

    public Practica03_a() {
        // Inicializar componentes y configurar la ventana
        setTitle("Practica 03");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panelFormulario = new JPanel();
        add(panelFormulario, BorderLayout.CENTER);
        panelFormulario.setLayout(null);

        // Inicializar controles
        Tid = new JTextField();
        Tid.setBounds(91, 20, 157, 20);
        panelFormulario.add(Tid);

        Tinsumo = new JTextField();
        Tinsumo.setBounds(91, 40, 157, 20);
        panelFormulario.add(Tinsumo);

        Bagregar = new JButton("Agregar");
        Bagregar.setBounds(91, 80, 100, 20);
        panelFormulario.add(Bagregar);
        Bagregar.addActionListener(this);

        Beliminar = new JButton("Eliminar");
        Beliminar.setBounds(200, 80, 100, 20);
        panelFormulario.add(Beliminar);
        Beliminar.addActionListener(this);

        Bsalir = new JButton("Salir");
        Bsalir.setBounds(150, 110, 100, 20);
        panelFormulario.add(Bsalir);
        Bsalir.addActionListener(this);

        Bguardar = new JButton("Guardar");
        Bguardar.setBounds(91, 140, 100, 20);
        panelFormulario.add(Bguardar);
        Bguardar.addActionListener(this);
        Bguardar.setEnabled(false);

        Bcancelar = new JButton("Cancelar");
        Bcancelar.setBounds(200, 140, 100, 20);
        panelFormulario.add(Bcancelar);
        Bcancelar.addActionListener(this);
        Bcancelar.setEnabled(false);

        JScrollPane scrollPane_jList = new JScrollPane();
        scrollPane_jList.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane_jList.setBounds(91, 170, 157, 42);
        panelFormulario.add(scrollPane_jList);

        ListaCategoria = new JList<>();
        scrollPane_jList.setViewportView(ListaCategoria);

        inicializarcategorias();
    }

    public void inicializarcategorias() {
        archivo = new Archivotxt();
        this.listaCategorias = new ListaCategorias();
        // Asumiendo que existe un método `existe` y `cargar` en la clase Archivotxt
        if (this.archivo.existe()) {
            this.listaCategorias.CategoriasArreglo();
        }
        modeloCategoria = new DefaultListModel<>();
        this.modeloCategoria = this.listaCategorias.generarModeloCategorias();
        ListaCategoria.setModel(modeloCategoria);
    }

    public Boolean esdatocompleto() {
        boolean enc = false;
        String id, insumo, idcategoria;
        id = "";
        insumo = "";
        idcategoria = "";

        id = this.Tid.getText().trim();
        insumo = this.Tinsumo.getText().trim();

        if (this.ListaCategoria.getSelectedIndex() >= 0) {
            idcategoria = this.modeloCategoria.get(this.ListaCategoria.getSelectedIndex()).getIdcategoria();
        }
        
        enc = !id.isEmpty() && !insumo.isEmpty() && !idcategoria.isEmpty();

        System.out.println(id + " " + insumo + " " + idcategoria);
        return enc;
    }

    public void Volveralinicio() {
        this.Bagregar.setText("Agregar");
        this.Bsalir.setText("Salir");
        this.Beliminar.setEnabled(true);
        this.Tid.setEditable(false);
        this.Tinsumo.setEditable(false);
        this.ListaCategoria.setEnabled(false);
        this.Tid.setText("");
        this.Tinsumo.setText("");
        this.ListaCategoria.setSelectedIndex(0);
    }


    public void Altas() {
        if (this.Bagregar.getText().toUpperCase().compareTo("AGREGAR") == 0) {
            this.ListaCategoria.setSelectedIndex(0);
            this.Tid.setText(this.Tid.getText().trim());
            this.Tinsumo.setText("");
            this.Beliminar.setEnabled(false);
            this.Bguardar.setEnabled(true);
            this.Bcancelar.setEnabled(true);
            this.Tid.setEditable(true);
            this.Tinsumo.setEditable(true);
            this.ListaCategoria.setEnabled(true);
        } else {
            if (esdatocompleto()) {
                System.out.println("aqui");
                String id, insumo, idcategoria;
                id = Tid.getText().trim();
                insumo = Tinsumo.getText().trim();
                idcategoria = modeloCategoria.get(this.ListaCategoria.getSelectedIndex()).getIdcategoria();
                
                Insumo nuevo = new Insumo(id, insumo, idcategoria); 
                
                if (!this.listaInsumos.buscarInsumo(nuevo).isPresent()) { 
                    listaInsumos.agregarInsumo(nuevo); 
                    String mensaje = "Lo siento, el id ya existe: " + id;
                    JOptionPane.showMessageDialog(null, mensaje); 
                } else { 
                    JOptionPane.showMessageDialog(null, "El insumo ya existe"); 
                }
            } else { 
                JOptionPane.showMessageDialog(null, "Faltan datos"); 
            }
        }
    }

public static void main(String[] args) {
    Practica03_a frame = new Practica03_a();
    frame.setVisible(true);
}

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
}
}
   