package Vista;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Practica03_d extends JFrame implements ActionListener {

    // Declaración de los controles
    private JTextField Tid, Tinsumo, Tcategoria;
    private JButton Bagregar, Beliminar, Bsalir;
    private JPanel panelFormulario;

    public Practica03_d() {
        // Inicializar componentes y configurar la ventana
        setTitle("Administración de Productos");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panelFormulario = new JPanel();
        getContentPane().add(panelFormulario, BorderLayout.CENTER);
        panelFormulario.setLayout(null);

        // Inicializar controles
        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(24, 20, 33, 20);
        panelFormulario.add(lblId);

        Tid = new JTextField();
        Tid.setBounds(67, 20, 83, 20);
        panelFormulario.add(Tid);

        JLabel lblInsumo = new JLabel("Insumo:");
        lblInsumo.setBounds(160, 20, 50, 20);
        panelFormulario.add(lblInsumo);

        Tinsumo = new JTextField();
        Tinsumo.setBounds(218, 20, 132, 20);
        panelFormulario.add(Tinsumo);

        JLabel lblCategoria = new JLabel("Categoría:");
        lblCategoria.setBounds(50, 100, 100, 20);
        panelFormulario.add(lblCategoria);

        Tcategoria = new JTextField();
        Tcategoria.setBounds(150, 100, 200, 39);
        panelFormulario.add(Tcategoria);

        Bagregar = new JButton("Agregar");
        Bagregar.setBounds(24, 209, 100, 30);
        panelFormulario.add(Bagregar);
        Bagregar.addActionListener(this);

        Beliminar = new JButton("Eliminar");
        Beliminar.setBounds(150, 209, 100, 30);
        panelFormulario.add(Beliminar);
        Beliminar.addActionListener(this);

        Bsalir = new JButton("Salir");
        Bsalir.setBounds(274, 209, 100, 30);
        panelFormulario.add(Bsalir);
        Bsalir.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Bagregar) {
            // Implementar la lógica para agregar
            String id = Tid.getText().trim();
            String insumo = Tinsumo.getText().trim();
            String categoria = Tcategoria.getText().trim();

            if (!id.isEmpty() && !insumo.isEmpty() && !categoria.isEmpty()) {
                System.out.println("Agregar: " + id + ", " + insumo + ", " + categoria);
                // Aquí puedes agregar la lógica para agregar el insumo
            } else {
                System.out.println("Faltan datos");
            }
            
        } else if (e.getSource() == Beliminar) {
            // Implementar la lógica para eliminar
            String id = Tid.getText().trim();
            if (!id.isEmpty()) {
                System.out.println("Eliminar: " + id);
                // Aquí puedes agregar la lógica para eliminar el insumo por ID
            } else {
                System.out.println("ID vacío");
            }
            
        } else if (e.getSource() == Bsalir) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        Practica03_d frame = new Practica03_d();
        frame.setVisible(true);
    }
}

