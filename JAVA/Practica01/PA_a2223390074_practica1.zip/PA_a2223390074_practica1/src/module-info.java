/**
 * 
 */
/**
 * 
 */
module PA_a2223390074_practica1 {
	requires java.desktop;
	requires xstream;
}